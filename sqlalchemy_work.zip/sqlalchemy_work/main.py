from data import db_session
from jobs import *
from users import *
from flask import Flask, render_template

app = Flask(__name__)


def main():
    app.run(port=8080, host='127.0.0.1')


@app.route('/')
def journal():
    db_session.global_init('db/blogs1.sqlite')
    session = db_session.create_session()
    jobs = session.query(Jobs).all()
    team_leaders = [session.query(User).filter_by(id=job.team_leader).first() for job in jobs]
    return render_template('Jobs journal.html', jobs=jobs, team_leaders=team_leaders)


if __name__ == '__main__':
    main()
